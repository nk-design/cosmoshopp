const slider = require('./db_slider.json');
const products = require('./db_products.json');

module.exports = () => ({
  slider: slider,
  products: products
});