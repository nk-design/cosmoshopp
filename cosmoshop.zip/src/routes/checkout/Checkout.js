import "./Checkout.scss";
import Breadcrumbs from "../../components/breadcrumbs/Breadcrumbs";
import { useContext, useState } from "react";
import UsersContext from "../../Context";
import { Link, useNavigate } from "react-router-dom";

const Checkout = ({openAccount, accountIsOpen}) => {
    const {cart, setCart} = useContext(UsersContext);
    const navigate = useNavigate()
    const [shippingValue, setShippingValue] = useState(null);

    const handleSubmit = (event) => {
        event.preventDefault();
        navigate("/thankyou");
        setCart([]);
    }

    function generate_url(str)
    {
      let url = str.replace(/[\s]+/gi, '-');
      url = translit(url);
      url = url.replace(/[^0-9a-z_-]+/gi, '').toLowerCase();	
      return url;
    }
    
    function translit(str)
    {
      let ua=("А-а-Б-б-В-в-Ґ-ґ-Г-г-Д-д-Е-е-Ё-ё-Є-є-Ж-ж-З-з-И-и-І-і-Ї-ї-Й-й-К-к-Л-л-М-м-Н-н-О-о-П-п-Р-р-С-с-Т-т-У-у-Ф-ф-Х-х-Ц-ц-Ч-ч-Ш-ш-Щ-щ-Ъ-ъ-Ы-ы-Ь-ь-Э-э-Ю-ю-Я-я").split("-")   
      let en=("A-a-B-b-V-v-G-g-G-g-D-d-E-e-E-e-E-e-ZH-zh-Z-z-I-i-I-i-I-i-J-j-K-k-L-l-M-m-N-n-O-o-P-p-R-r-S-s-T-t-U-u-F-f-H-h-TS-ts-CH-ch-SH-sh-SCH-sch-'-'-Y-y-'-'-E-e-YU-yu-YA-ya").split("-")   
         let res = '';
      for(let i=0, l=str.length; i<l; i++)
      { 
        let s = str.charAt(i), n = ua.indexOf(s); 
        if(n >= 0) { res += en[n]; } 
        else { res += s; } 
        } 
        return res;  
    }

    return (<section className="checkout">
        <Breadcrumbs links={[{path:"/checkout", linkName: "Оформлення замовлення"}]}/>

        {cart.length>0?(
        <div className="checkout__wrapper">
            <div className="checkout__contact">
                <div className="checkout__contact__info">
                    <div className="checkout__contact__info__title">
                        <h1>КОНТАКТНА ІНФОРМАЦІЯ</h1>
                        <span>Аккаунт вже існує?</span>
                        <span onClick={()=>openAccount(!accountIsOpen)}>Увійти</span>
                    </div>

                    <form className="checkout__contact__form" onSubmit={handleSubmit}>
                        <p>*Ім'я:</p>
                        <input required autoComplete="on" type="text" placeholder="Введіть ім'я"/>

                        <p>*Прізвище:</p>
                        <input required autoComplete="on" type="text" placeholder="Введіть прізвище"/>

                        <p>*Номер телефону:</p>
                        <input required autoComplete="on" type="number" placeholder="+380 (__) ___ __ __"/>

                        <p>Email:</p>
                        <input autoComplete="on" type="email" placeholder="Введіть email"/>

                        <h2>ДОСТАВКА</h2>

                        <p>*Оберіть спосіб доставки:</p>
                        <div className="checkout__contact__shipping">
                            <div>
                                <label htmlFor="NovaPoshta" onClick={()=>setShippingValue("NovaPoshta")}>Нова Пошта
                                    <input required id="NovaPoshta" type="radio" value="NovaPoshta" name="shipping"/>
                                </label>

                                <label htmlFor="Samovyviz" onClick={()=>setShippingValue("Samovyviz")}>Самовивіз
                                    <input required id="Samovyviz" type="radio" value="Samovyviz" name="shipping"/>
                                </label>
                            </div>

                            {shippingValue === "NovaPoshta"? (<div>
                                <p>*Область:</p>
                                <input required autoComplete="on" type="text" placeholder="Введіть область"/>

                                <p>*Місто:</p>
                                <input required autoComplete="on" type="text" placeholder="Введіть місто"/>

                                <p>*Відділення:</p>
                                <input required autoComplete="on" type="text" placeholder="Введіть відділення"/>
                            </div>): shippingValue === "Samovyviz"? (<div>
                                <p>Точка самовивозу: м. Дніпро, вул. Гоголя 8</p>
                                <p>Часи роботи: 10:00 - 20:00</p>
                            </div>):""}
                        </div>

                        <h2>ОПЛАТА</h2>

                        <p>*Оберіть спосіб оплати:</p>
                        <div className="checkout__contact__payment">
                            <label htmlFor="Card">Банківська карта</label>
                            <input disabled required id="Card" type="radio" value="Банківська карта" name="payment"/>

                            <label htmlFor="Cash">Оплата при отриманні</label>
                            <input required id="Cash" type="radio" value="Оплата при отриманні" name="payment"/>
                        </div>

                        <p>Оформлюючи замовлення ви даєте згоду на обробку персональних даних, та інше, що описано на сторінці політика конфіденційності.</p>

                        <p>Промокод:</p>
                        <input autoComplete="on" type="text" placeholder="Введіть промокод"/>

                        <p>Коментар до замовлення:</p>
                        <input autoComplete="on" type="text" placeholder="Ваш коментар"/>

                        <button type="submit">Замовити</button>
                    </form>
                </div>
            </div>
            <div className="checkout__finish">
                <h2>ВАШЕ ЗАМОВЛЕННЯ:</h2>
                <div className="checkout__finish__cart">
                    {cart.map(el => {
                        return (
                            <Link key={el.id} className="checkout__finish__cart__product" to={"/catalogue/" + el.type + "/" + el.id + "/" + generate_url(el.title)}>
                                <div>
                                    <img alt="PRODUCTSIMAGE" src={el.image}/>
                                </div>
                                <div>
                                    <h2>{el.title}</h2>
                                    <p>Колір: {el.color}</p>
                                    <p>Кількість: {el.quantity}</p>
                                    <p>Номер товару: {el.id}</p>
                                    {el.discount?<>
                                    Ціна: <span className="cart__product__description__discount">{el.price} UAH</span>
                                    <span>{(100 - el.discount)/100 * el.price} UAH</span></>:
                                    <p>Ціна: {el.price} UAH</p>}
                                </div>
                            </Link>
                        )
                    })}
                </div>

                <h3>ЗАГАЛОМ ДО СПЛАТИ: {cart.reduce((acc, el) => el.discount?acc += (100 - el.discount)/100 * el.price * el.quantity:acc += el.price * el.quantity, 0)} UAH</h3>
                <p>Доставка за тарифами пошти</p>
            </div>
        </div>):<div className="cart__disclaimer">
                    <h2>Кошик порожній.</h2>
                    <p >Обраний товар буде відображатись тут</p>
                </div>}
    </section>)
}

export default Checkout;