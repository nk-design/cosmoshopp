import "./Admin.scss"
import { useContext, useState, Fragment } from "react";
import UsersContext from "../../Context";

const Admin = () => {
    const {productsData, handleDelete, handleEdit} = useContext(UsersContext);

    const [change, setChange] = useState(false);

    console.log(productsData)

    return <section className="admin">
        {productsData.map(el => {
            return <div className="admin__product" key={el.id}>
                <p>id: {change?<input defaultValue={el.id}/>:el.id}</p>
                <p>More: {change?<input defaultValue={el.more}/>:el.more}</p>
                <p>Type: {change?<input defaultValue={el.type}/>:el.type}</p>
                <p>Title: {change?<input defaultValue={el.title}/>:el.title}</p>
                <p>Brand: {change?<input defaultValue={el.brand}/>:el.brand}</p>
                <p>Image: {el.image.map((el2,id) => change?<input key={id} defaultValue={el2}/>:<Fragment key={id}><span >{el2}</span><br/></Fragment>)}</p>
                <p>Usage: {change?<input defaultValue={el.usage}/>:el.usage}</p>
                <p>Price: {change?<input defaultValue={el.price}/>:el.price}</p>
                {/* <p>Color: {change?<input defaultValue={el.color}/>:el.color}</p> */}
                <p>Quantity: {change?<input defaultValue={el.quantity}/>:el.quantity}</p>
                <p>Category: {change?<input defaultValue={el.category}/>:el.category}</p>
                <p>Discount: {change?<input defaultValue={el.discount}/>:el.discount}</p>
                <p>Ingredient: {change?<input defaultValue={el.ingredient}/>:el.ingredient}</p>
                <p>Description: {change?<input defaultValue={el.description}/>:el.description}</p>
                <button onClick={()=>change?(handleEdit(el.id,el),setChange(!change)):setChange(!change)}>EDIT</button>
                <button onClick={()=> handleDelete(el.id)}>DELETE</button>
                {/* <p onClick={(e) => (console.log(el),console.log(e))}>ASD</p> */}
            </div>
        })}
    </section>
}

export default Admin;