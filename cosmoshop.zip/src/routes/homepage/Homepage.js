import './Homepage.scss';
import Header from '../../components/header/Header';
import {ReactComponent as Instagram} from "../../resources/instagram.svg";
import EmailPromo from "../../resources/email_promo.png";
import {ReactComponent as RightArrow} from "../../resources/right_arrow.svg";
import { Link } from 'react-router-dom';

function Home() {
  return (
    <section>
      <Header />

      <div className='categories__title'>
        <p>Категорії</p>
      </div>

      <div className='categories__tiles'>
        
        <div className='categories__tiles__row'>
          <Link to="/catalogue/face" className='categories__tile face__tile'>
            <p>ОБЛИЧЧЯ</p>
          </Link>

          <Link to="/catalogue/hair" className='categories__tile hair__tile'>
            <p>ВОЛОССЯ</p>
          </Link>
        </div>

        <div className='categories__tiles__row'>
          <Link to="/catalogue/makeup" className='categories__tile makeup__tile'>
            <p>МАКІЯЖ</p>
          </Link>

          <Link to="/catalogue/sets" className='categories__tile packages__tile'>
            <p>НАБОРИ</p>
          </Link>
        </div>

      </div>


      <div className='email_promo'>
        <img alt="EMAIL_PROMO" src={EmailPromo}/>
        <div className='email_promo__description'>
          <p>Зареєструйся і отримай знижку 5% на перше замовлення</p>
          <Link to="/registration">Реєстрація <RightArrow/></Link>
        </div>
      </div>


      <div className='instagram__title'>
        <p>Instagram</p>
      </div>

      <div className='instagram__description'>
        <p>Слідкуйте за нами в instagram</p>
        <a className='instagram__link' href="https://www.instagram.com/cosmoshopp_ua/" rel="noreferrer" target="_blank"><Instagram /> cosmoshopp_ua</a>
        
      </div>      
    </section>
  );
}

export default Home;
