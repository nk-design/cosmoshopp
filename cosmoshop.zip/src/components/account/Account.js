import { useState } from "react"
import "./Account.scss"

const Account = ({openAccount, accountIsOpen}) => {

    const [emailValue, setEmailValue] = useState("");
    const [passwordValue, setPasswordValue] = useState("");

    const handleSubmit = (event) => {
        event.preventDefault();
    }


    return (<section className="account" onClick={(event)=>{
        if(event.target === event.currentTarget) {openAccount(!accountIsOpen)}}
        }>
        <form className="account__wrapper" onSubmit={handleSubmit}>
            <h1>Вхід</h1>
            <p>*Email чи телефон:</p>
            <input required autoComplete="on" type="email" placeholder="Email чи телефон" value={emailValue} onChange={(event) => setEmailValue(event.target.value)}/>
            <p>*Пароль:</p>
            <input required autoComplete="off" type="password" placeholder="Пароль" value={passwordValue} onChange={(event) => setPasswordValue(event.target.value)}/>
            <div className="account__buttons">
                <p>Забули пароль?</p>

                <button type="submit">Увійти</button>
            </div>
            <h2 className="account__close" onClick={()=>openAccount(!accountIsOpen)}>X</h2>
        </form>
    </section>)
}

export default Account;