import "./Header.scss";
import Carousel from "nuka-carousel";
import { Link } from "react-router-dom";
import { useCallback, useEffect, useState } from "react";

const Header = () => {
    const [sliderData, setSliderData] = useState([]);

    const fetchSlider = useCallback(async () => {
        const result = await fetch("http://localhost:3001/slider",{
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            'Accept': 'application/json'
          }
        }).then(response=>response).then(data=>data.json());
        
        setSliderData(result.slider)
    }, []);

    useEffect(() => {
       fetchSlider();
    },[fetchSlider])

    return (
        <div className="header__slider">
            <Carousel autoplay={true} dragging={true} speed={1500} wrapAround={true} pauseOnHover={true} autoplayInterval={7000}>
                {sliderData.map((el)=>{
                    return (
                        <div key={el.id}>
                            <div className="header__slider__text">
                                <h1>{el.title}</h1>
                                <p>{el.description}</p>
                                <Link to={el.buttonLink} className="grey__button">{el.button}</Link>
                            </div>
                            <img alt="HOMEPAGE SLIDER" src={el.image}/>
                        </div>
                    )
                })}
            </Carousel>
        </div>
    )
}

export default Header;