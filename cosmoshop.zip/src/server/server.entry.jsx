// import express from "express";
// import ReactDOMServer from "react-dom/server";
// import React from "react";
// import App from '../App';
// import { BrowserRouter } from 'react-router-dom';
// import { Provider } from '../Context';
// import ScrollUp from '../ScrollUp';
// import fs from "fs";
// import path from "path";

// const app = express();
// const PORT = 8000;

// app.use(express.static(path.resolve(__dirname,"..","build")))
// app.get( "*", express.static( path.resolve( __dirname, 'build' ) ) );

// app.use("^/$", (req,res,next) => {
//   fs.readFile(path.resolve("build/index.html"), "utf-8", (err,data) => {
//     if(err){
//       console.log(err)
//       return res.status(500).send("Error happened")
//     }

//     return res.send(
//       data.replace(
//         "<div id='root'></div>",
//         `<div id='root'>${ReactDOMServer.renderToString(
//             <React.StrictMode>
//             <BrowserRouter>
//               <Provider>
//                 <ScrollUp />
//                 <App />
//               </Provider>
//             </BrowserRouter>
//           </React.StrictMode>  
//         )}</div>`
//       )
//     )
//   })
// })


// app.listen(PORT, () => {
//   console.log("app launched")
// })