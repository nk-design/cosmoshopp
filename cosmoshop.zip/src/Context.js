import { createContext, useState, useCallback } from "react";

const UsersContext = createContext();

const Provider = ({children}) =>{
    const [productsData, setProductsData] = useState([]);
    const [currentProduct, setCurrentProduct] = useState('');
    const [cart, setCart] = useState([])
    // const [input, setValue] = useState("")

    const fetchProducts = useCallback(async () => {
        const result = await fetch("http://localhost:3001/products",{
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                'Accept': 'application/json'
            }
        }).then(response=>response).then(data=>data.json());
        
        setProductsData(result.products.sort((a,b) => b.quantity - a.quantity));     
    }, []);


    const handleDelete = async (id) => {
        await fetch(`http://localhost:3001/products/${id}`,{
            method: "DELETE"
        })
        const newProductsData = productsData.filter((elem)=>{
            return elem.id !== id;
        })
    
        setProductsData(newProductsData);
    };
    
    const handleEdit = async (id, newEl) => {
        // const result = await fetch(`http://localhost:3001/products/${id}`,{
        //     method: "PUT",
        //     headers: {
        //     "Content-Type": "application/json"
        //     },
        //     body: JSON.stringify({el: newEl})
        // }).then(response=>response).then(data=>data.json());
    
        const updatedProducts = productsData.filter((product)=>{
            if(product.id===id){
                return product = newEl;
            }
    
            return product
        })
    
        setProductsData(updatedProducts)
    };

    // const handleChange = (event) => {
    //     setValue(event.target.value)
    // }
    
    // const handleSubmit = async (event) =>{
    // event.preventDefault();
    // const result = await fetch("http://localhost:3001/books",{
    //     method: "POST",
    //     headers: {
    //     "Content-Type": "application/json"
    //     },
    //     body: JSON.stringify({title:input})
    // }).then(response=>response.json()).then(data=>data);

    // console.log(result)
    
    // setValue("")  
    // };

      const valueToShare = {
        productsData,
        currentProduct,
        setCurrentProduct,
        cart,
        setCart,
        // input,
        // handleChange,
        handleDelete,
        handleEdit,
        // handleSubmit,
        fetchProducts
      }


    return <UsersContext.Provider value={valueToShare}>
        {children}
    </UsersContext.Provider>
}

export {Provider};
export default UsersContext;